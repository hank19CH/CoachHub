<script setup lang="ts">
import { useRouter } from 'vue-router'
import { useAuthStore } from '@/stores/auth'

const router = useRouter()
const authStore = useAuthStore()

async function handleSignOut() {
  await authStore.signOut()
  router.push('/login')
}
</script>

<template>
  <div class="p-4">
    <h1 class="font-display text-2xl font-bold text-gray-900 mb-6">Settings</h1>

    <div class="space-y-4">
      <!-- Account section -->
      <div class="card p-4">
        <h2 class="font-semibold text-gray-900 mb-3">Account</h2>
        <div class="space-y-2">
          <button class="w-full flex items-center justify-between p-3 rounded-xl hover:bg-gray-50">
            <span>Edit Profile</span>
            <svg xmlns="http://www.w3.org/2000/svg" class="w-5 h-5 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
              <path stroke-linecap="round" stroke-linejoin="round" d="M9 5l7 7-7 7" />
            </svg>
          </button>
          <button class="w-full flex items-center justify-between p-3 rounded-xl hover:bg-gray-50">
            <span>Change Password</span>
            <svg xmlns="http://www.w3.org/2000/svg" class="w-5 h-5 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
              <path stroke-linecap="round" stroke-linejoin="round" d="M9 5l7 7-7 7" />
            </svg>
          </button>
          <button class="w-full flex items-center justify-between p-3 rounded-xl hover:bg-gray-50">
            <span>Privacy</span>
            <svg xmlns="http://www.w3.org/2000/svg" class="w-5 h-5 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
              <path stroke-linecap="round" stroke-linejoin="round" d="M9 5l7 7-7 7" />
            </svg>
          </button>
        </div>
      </div>

      <!-- Support section -->
      <div class="card p-4">
        <h2 class="font-semibold text-gray-900 mb-3">Support</h2>
        <div class="space-y-2">
          <button class="w-full flex items-center justify-between p-3 rounded-xl hover:bg-gray-50">
            <span>Help Center</span>
            <svg xmlns="http://www.w3.org/2000/svg" class="w-5 h-5 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
              <path stroke-linecap="round" stroke-linejoin="round" d="M9 5l7 7-7 7" />
            </svg>
          </button>
          <button class="w-full flex items-center justify-between p-3 rounded-xl hover:bg-gray-50">
            <span>Report a Problem</span>
            <svg xmlns="http://www.w3.org/2000/svg" class="w-5 h-5 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
              <path stroke-linecap="round" stroke-linejoin="round" d="M9 5l7 7-7 7" />
            </svg>
          </button>
        </div>
      </div>

      <!-- Sign out -->
      <button 
        @click="handleSignOut"
        class="w-full p-4 text-red-600 font-medium rounded-xl border border-red-200 hover:bg-red-50 transition-colors"
      >
        Sign Out
      </button>

      <!-- Version -->
      <p class="text-center text-gray-400 text-sm">
        CoachHub v0.1.0
      </p>
    </div>
  </div>
</template>
