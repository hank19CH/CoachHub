<script setup lang="ts">
</script>

<template>
  <div class="p-6 text-center">
    <div class="w-20 h-20 mx-auto mb-6 rounded-full bg-summit-100 flex items-center justify-center">
      <svg xmlns="http://www.w3.org/2000/svg" class="w-10 h-10 text-summit-600" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.5">
        <path stroke-linecap="round" stroke-linejoin="round" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
      </svg>
    </div>
    <h1 class="font-display text-2xl font-bold text-gray-900 mb-2">Explore</h1>
    <p class="text-gray-600">Discover coaches, athletes, and training content.</p>
    <p class="text-gray-400 text-sm mt-4">Coming soon...</p>
  </div>
</template>
