<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { useAuthStore } from '@/stores/auth'
import { supabase } from '@/lib/supabase'
import type { Profile } from '@/types/database'

const route = useRoute()
const router = useRouter()
const authStore = useAuthStore()

const profile = ref<Profile | null>(null)
const loading = ref(true)
const isOwnProfile = computed(() => {
  if (!route.params.username) return true
  return route.params.username === authStore.profile?.username
})

const displayProfile = computed(() => {
  return isOwnProfile.value ? authStore.profile : profile.value
})

const initials = computed(() => {
  if (!displayProfile.value) return '?'
  return displayProfile.value.display_name
    .split(' ')
    .map(n => n[0])
    .join('')
    .toUpperCase()
    .slice(0, 2)
})

onMounted(async () => {
  if (!isOwnProfile.value && route.params.username) {
    await fetchProfile(route.params.username as string)
  } else {
    loading.value = false
  }
})

async function fetchProfile(username: string) {
  try {
    loading.value = true
    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .eq('username', username)
      .single()

    if (error) throw error
    profile.value = data
  } catch (e) {
    console.error('Error fetching profile:', e)
    router.push('/404')
  } finally {
    loading.value = false
  }
}
</script>

<template>
  <div v-if="loading" class="p-6 text-center">
    <div class="animate-pulse space-y-4">
      <div class="w-24 h-24 mx-auto rounded-full bg-gray-200"></div>
      <div class="h-6 w-32 mx-auto bg-gray-200 rounded"></div>
      <div class="h-4 w-24 mx-auto bg-gray-200 rounded"></div>
    </div>
  </div>

  <div v-else-if="displayProfile" class="pb-6">
    <!-- Profile Header -->
    <div class="p-6 text-center">
      <!-- Avatar -->
      <div class="w-24 h-24 mx-auto mb-4">
        <img
          v-if="displayProfile.avatar_url"
          :src="displayProfile.avatar_url"
          :alt="displayProfile.display_name"
          class="w-full h-full rounded-full object-cover ring-4 ring-white shadow-lg"
        />
        <div 
          v-else 
          class="w-full h-full rounded-full bg-gradient-to-br from-summit-600 to-summit-800 flex items-center justify-center text-white font-bold text-2xl ring-4 ring-white shadow-lg"
        >
          {{ initials }}
        </div>
      </div>

      <!-- Name & username -->
      <h1 class="font-display text-2xl font-bold text-gray-900">
        {{ displayProfile.display_name }}
      </h1>
      <p class="text-gray-500">@{{ displayProfile.username }}</p>

      <!-- User type badge -->
      <div class="mt-2">
        <span 
          class="badge"
          :class="{
            'badge-coach': displayProfile.user_type === 'coach',
            'bg-blue-100 text-blue-700': displayProfile.user_type === 'athlete',
            'bg-gray-100 text-gray-700': displayProfile.user_type === 'follower'
          }"
        >
          {{ displayProfile.user_type.charAt(0).toUpperCase() + displayProfile.user_type.slice(1) }}
        </span>
      </div>

      <!-- Bio -->
      <p v-if="displayProfile.bio" class="mt-4 text-gray-700 max-w-sm mx-auto">
        {{ displayProfile.bio }}
      </p>

      <!-- Action buttons -->
      <div class="mt-6 flex gap-3 justify-center">
        <template v-if="isOwnProfile">
          <router-link to="/settings" class="btn-secondary">
            Edit Profile
          </router-link>
        </template>
        <template v-else>
          <button class="btn-primary">Follow</button>
          <button class="btn-secondary">Message</button>
        </template>
      </div>
    </div>

    <!-- Stats -->
    <div class="flex justify-center gap-8 py-4 border-y border-feed-border">
      <div class="text-center">
        <p class="font-bold text-gray-900">0</p>
        <p class="text-sm text-gray-500">Posts</p>
      </div>
      <div class="text-center">
        <p class="font-bold text-gray-900">0</p>
        <p class="text-sm text-gray-500">Followers</p>
      </div>
      <div class="text-center">
        <p class="font-bold text-gray-900">0</p>
        <p class="text-sm text-gray-500">Following</p>
      </div>
    </div>

    <!-- Posts grid placeholder -->
    <div class="p-6 text-center text-gray-500">
      <svg xmlns="http://www.w3.org/2000/svg" class="w-12 h-12 mx-auto mb-3 text-gray-300" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.5">
        <path stroke-linecap="round" stroke-linejoin="round" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
      </svg>
      <p>No posts yet</p>
    </div>
  </div>
</template>
